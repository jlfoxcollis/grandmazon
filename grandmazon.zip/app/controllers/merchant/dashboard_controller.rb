class Merchant::DashboardController < Merchant::BaseController

  def index
  end
end
