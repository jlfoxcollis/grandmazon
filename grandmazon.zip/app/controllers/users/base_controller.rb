class Users::BaseController < ApplicationController
end
