class Users::UsersController < ApplicationController

  def show
  end

end
